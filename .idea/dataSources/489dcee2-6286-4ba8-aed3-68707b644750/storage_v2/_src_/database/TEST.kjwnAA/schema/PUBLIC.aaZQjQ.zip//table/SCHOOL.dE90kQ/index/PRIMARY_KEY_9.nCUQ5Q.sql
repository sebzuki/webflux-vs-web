create unique index PRIMARY_KEY_9
    on SCHOOL (ID);


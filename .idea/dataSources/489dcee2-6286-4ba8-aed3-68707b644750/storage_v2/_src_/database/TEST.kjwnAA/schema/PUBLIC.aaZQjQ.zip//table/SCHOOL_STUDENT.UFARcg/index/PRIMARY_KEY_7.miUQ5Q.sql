create unique index PRIMARY_KEY_7
    on SCHOOL_STUDENT (SCHOOL_ID, STUDENT_ID);

